package jB;
import java.io.Serializable;

public class javabean implements Serializable {
public javabean()
	{
		}
private String name;
private String add;
private String phone;
private String id;
private String course;
/**
 * @return the name
 */

public String getName() {
	return name;
}
/**
 * @param name the name to set
 */
public void setName(String name) {
	this.name = name;
}
/**
 * @return the add
 */
public String getAdd() {
	return add;
}
/**
 * @param add the add to set
 */
public void setAdd(String add) {
	this.add = add;
}
/**
 * @return the phone
 */
public String getPhone() {
	return phone;
}
/**
 * @param phone the phone to set
 */
public void setPhone(String phone) {
	this.phone = phone;
}
/**
 * @return the id
 */
public String getId() {
	return id;
}
/**
 * @param id the id to set
 */
public void setId(String id) {
	this.id = id;
}
/**
 * @return the course
 */
public String getCourse() {
	return course;
}
/**
 * @param course the course to set
 */
public void setCourse(String course) {
	this.course = course;
}

	
}


