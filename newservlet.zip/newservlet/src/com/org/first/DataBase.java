/**
 * 
 */
/**
 * @author dhivya.a
 *
 */
package com.org.first;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DataBase{
	public String driverName = "oracle.jdbc.driver.OracleDriver";
	public String driverpath = "jdbc:oracle:thin:@10.100.1.30:1521:";
	public String dbname = "kurnia";
	public String username = "kurniadev";
	public String password = "system";
	Connection con = null;
	Statement stmt = null;
	ResultSet rs = null;

	public DataBase() throws ClassNotFoundException, SQLException {
		Class.forName(driverName);
		con = DriverManager.getConnection(driverpath + dbname, username,
				password);
	}

	public int insertData(String query) {
		int i = 0;
		try {
			stmt = con.createStatement();
			i = stmt.executeUpdate(query);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;

	}

	public int updateData(String query) {
		int i = 0;
		try {
			stmt = con.createStatement();
			i = stmt.executeUpdate(query);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;

	}

	public int deleteData(String query) {
		int i = 0;
		try {
			stmt = con.createStatement();
			i = stmt.executeUpdate(query);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;

	}

	public ResultSet result(String query) {

		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rs;

	}
}