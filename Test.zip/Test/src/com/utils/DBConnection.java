package com.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {

	 public static Connection getDirectConnection(){
     Connection con=null;
          try{
        Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@10.100.1.30:1521:kurnia","kurniadev","system");
          }catch(Exception e){
                        e.printStackTrace();
          }
          return(con);
    }
	 
	  public static void closeStatement(Statement stmt) {
	        try {
	            if (stmt != null) {
	                stmt.close();
	            }
	        } catch (Exception e) {
	        	System.out.println(e);
	        }
	    }
	  
	    public static void closeResultSet(ResultSet result){
	            try {
	                if (result != null) {
	                    result.close();
	                }
	            } catch (SQLException se) {
	                System.out.println(se);
	            }
	        }
	    
	    public static void closeConnection(Connection dbConnection){
	            try {
	                if ((dbConnection != null) && !dbConnection.isClosed()) {
	                    dbConnection.close();
	                }
	            } catch (SQLException se) {
	               System.out.println(se);
	            }
	        }
}
