package com.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import oracle.jdbc.driver.OracleTypes;

import com.utils.DBConnection;

public class LoginDAO {
	
	
	public static String validateUser(String userName,String password){
		Connection connection=null;
		CallableStatement callableStatement=null;
		String status=null;
		try {
			connection=DBConnection.getDirectConnection();
			callableStatement=connection.prepareCall("{CALL PKG_TEST.PRVALIDATE(?,?,?)}");
			callableStatement.setString(1, userName);
			callableStatement.setString(2, password);
			callableStatement.registerOutParameter(3,OracleTypes.VARCHAR);
			callableStatement.execute();
			status=(String)callableStatement.getObject(3);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBConnection.closeStatement(callableStatement);
			DBConnection.closeConnection(connection);
		}
		return status;
	}
}
