

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class servletsimple
 */
public class servletsimple extends HttpServlet {
	
	/* The serialVersionUID is a universal version identifier for a Serializable class. Deserialization
	uses this number to ensure that a loaded class corresponds exactly to a serialized object. 
	 Consequence of not specifying serialVersionUID is that when you add or modify any field in class 
	 then already serialized class will not be able to recover because serialVersionUID generated for new class and for
	 old serialized object will be different. Java serialization process relies on correct 
	 serialVersionUID for recovering state of serialized object and throws java.io.InvalidClassException in case of serialVersionUID mismatch */
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public servletsimple() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		combine(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		combine(request, response);
	}
	
	protected void combine(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//It basically tells the client (the web browser) what content type it is so that it knows what to do with it
		 response.setContentType("text/html");
		 Connection con =null;
		 
		 //parsing a String method argument into an Integer object
		 int id1= Integer.parseInt(request.getParameter("id"));
		 
		 //to get the value of a form parameter
		 String name=request.getParameter("n1");
		 
		 String del=request.getParameter("d1");
		 
		 /* PrintWriter: prints text data to a character stream. 
			getWriter :Returns a PrintWriter object that can send character text to the client.*/
	      PrintWriter out = response.getWriter();
	      
	      try
	      {
	    	  con = DBconn.getConnection();   
	    	   	  
	    	  /* This statement gives you the flexibility of supplying arguments dynamically
	    	   * All parameters in JDBC are represented by the ? symbol, which is known as the parameter marker. 
	    	   * You must supply values for every parameter before executing the SQL statement.
	    	   */
	    	  PreparedStatement pst = con.prepareStatement("insert into bootcamp values(?,?)");
	    	  
	    	  pst.setInt(1,id1);  
	          pst.setString(2,name);   
	          
	          //Returns the number of rows affected by the execution of the SQL statement
	    	  int i = pst.executeUpdate();
	    	  //execute(): Returns a boolean value of true if a ResultSet object can be retrieved; otherwise, it returns false
	    	  //
	          out.println(i +"Record Inserted");
	    	 
	    	 
	    	 PreparedStatement st=con.prepareStatement("delete from bootcamp where name=?");  
	    	 st.setString(1,del);  
	    	   
	    	 int j=st.executeUpdate();  
	    	 out.println(j+" Records deleted");  
	    	 
	    	 
	      }
	      catch(Exception e)
	      {
	    	  e.printStackTrace();
	      }
	      
	     finally
	      {
	    	  try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	      }
	      
	      out.println("</body>");
	      out.println("</html>");
		
		
	}

}
