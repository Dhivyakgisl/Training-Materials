import java.sql.Connection;
import java.sql.DriverManager;

public class DBconn {
	
	public static Connection getConnection() { //Static : It means that this class is not instance related but class related. It can be accessed without creating the instance of Class.
		
		//Initialize the connection variable
		Connection con =null;
		
		try{
			//to dynamically load the driver's class file into memory, which automatically registers it
			Class.forName("oracle.jdbc.driver.OracleDriver"); //to register the Oracle driver
			
			//to establish a connection
			//getConnection(String url, String user, String password)
			//url - jdbc:oracle:thin:@hostname:port Number:databaseName
			//The getConnection() method of DriverManager class is used to establish connection with the database
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.100.1.30:1521:kurnia","kurniadev","system");
			}
		catch (Exception e)
		{
			e.printStackTrace();
			
			/* With println: you only know what exception has been thrown
			java.lang.UnsupportedOperationException: Not yet implemented
			
			With printStackTrace: you also know what caused it (line numbers + call stack)
			java.lang.UnsupportedOperationException: Not yet implemented
			at javaapplication27.Test1.test(Test1.java:27)
			at javaapplication27.Test1.main(Test1.java:19) */
		}
		
		return con;
		
	}
	
}
