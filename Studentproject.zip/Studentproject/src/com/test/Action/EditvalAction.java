package com.test.Action;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.test.bean.RegisterBean;
import com.test.dao.StudentDaoImpl;

public class EditvalAction extends Action {
	
	public ActionForward execute(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response) throws Exception
	{
	
		HttpSession session=request.getSession(true);
		 
		PrintWriter out=response.getWriter();
		RegisterBean rb=(RegisterBean)form;
		
String edit=request.getParameter("editvalue");
int x=Integer.parseInt(edit);
rb.setHndeditInd(x);
System.out.println("edit value is:"+edit);
ArrayList editlist=new ArrayList();
      
		try{ 
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@10.100.1.30:1521:kurnia","kurniadev","system");    
			Statement stmt=con.createStatement();  
			 
			 ResultSet rst=stmt.executeQuery("select * from mad_tb_register where num_sid='"+edit+"'"); 
			 while(rst.next())
			 {
				 
				editlist.add(rst.getInt("NUM_SID"));
				editlist.add(rst.getString("VCH_SNAME"));
				editlist.add(rst.getString("DT_DOB"));
				editlist.add(rst.getString("VCH_GENDER"));
				editlist.add(rst.getString("VCH_STATE"));
				editlist.add(rst.getString("VCH_CITY"));
				editlist.add(rst.getString("VCH_DEPARTMENT"));
				editlist.add(rst.getString("VCH_YEAR"));
				editlist.add(rst.getString("VCH_LANGUAGE"));
				editlist.add(rst.getString("VCH_PSWORD"));
				editlist.add(rst.getString("VCH_CON_PSWORD"));
				editlist.add(rst.getString("VCH_EMAIL"));
				editlist.add(rst.getString("NUM_MOBILENO"));
				
			 
				System.out.println("Edit value is:"+editlist);
				
				
			 }
			 response.setHeader("Cache-Control", "no-cache");
	         response.setHeader("Pragma", "no-cache");
	         out.print(editlist);
	         request.setAttribute("editlist",editlist);
	         request.setAttribute("edit","Edited Successfully");
	         session.setAttribute("editlist",editlist);
			
			}catch(Exception e){ System.out.println("Edit Error:"+e);}
		
		return null;
	}

}
