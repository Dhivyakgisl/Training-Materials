package com.test.Action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.test.dao.StudentDaoImpl;

public class ExportXml extends Action{		
		@Override
		public ActionForward execute(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response)
		{
			StudentDaoImpl studentDaoImpl=new StudentDaoImpl();
			studentDaoImpl.exportXml();
			return mapping.findForward("xmlval");
		}


	}


