package com.test.Action;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

import com.test.bean.UploadBean;


public class UploadAction extends Action {
	
	public ActionForward execute(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response)
	{
		UploadBean uploadBean=(UploadBean)form;
		FormFile file=uploadBean.getFile();
		String fileConvert=file.toString();
		String chk="C:/Users/Public/Pictures/Sample Pictures/"+fileConvert;
		System.out.println("file name is: "+chk);
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@10.100.1.30:1521:kurnia","kurniadev","system");    
			File imgfile=new File(chk);
			FileInputStream fin=new FileInputStream(imgfile);
			PreparedStatement ps=con.prepareStatement("insert into mad_tb_img values(?,?)");
			ps.setInt(1,11);
			ps.setBinaryStream(2,fin,(int)imgfile.length());
			ps.execute();
			System.out.println(" image saved successfully");
			}
		catch(Exception e)
		{
			System.out.println("Upload error  :"+e);
		}
		
		
		return mapping.findForward("uploadfile");
	}


}
