package com.test.Action;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.digester.xmlrules.CircularIncludeException;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class StateAction extends Action {
	
	@Override
	public ActionForward execute(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response)throws Exception
	{
		
		HttpSession session=request.getSession(true);
		PrintWriter out=response.getWriter();
		String getstate=request.getParameter("stateval");
		ArrayList citylist=new ArrayList();
		String totcity = null;
		
		
		try
		{
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection  con = DriverManager.getConnection("jdbc:oracle:thin:@10.100.1.30:1521:kurnia","kurniadev","system");
         PreparedStatement ps=con.prepareStatement("select VCH_CITY_NAME from MAD_TB_STUDENT_CITY  where NUM_STATE_ID='"+getstate+"'");
		ResultSet rst=ps.executeQuery();
		
		while(rst.next())
		{
		 totcity=rst.getString("VCH_CITY_NAME");	
		citylist.add(totcity);
		
		
		}
		System.out.println("city list is:"+citylist);
		
		
		 response.setHeader("Cache-Control", "no-cache");
         response.setHeader("Pragma", "no-cache");
         out.print(citylist);
         request.setAttribute("citylist",citylist);
         session.setAttribute("city",citylist);
         System.out.println("city list is:"+citylist);
		con.close();
		
		
		}catch(Exception e)
		{
			System.out.println("The error"+e);
		}
		
		citylist.clear();
		
		return null;
		
	}

}
