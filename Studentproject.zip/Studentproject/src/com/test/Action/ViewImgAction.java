package com.test.Action;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.test.dao.StudentDaoImpl;

public class ViewImgAction extends Action{

	public  ActionForward execute(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response)
	{
		File file = new File("d:\\sample");
		if (!file.exists()) {
			if (file.mkdir()) {
				System.out.println("Directory is created!");
			} else {
				System.out.println("Failed to create directory!");
			
		
			}
		}
		HttpSession session =request.getSession(true);
		ArrayList imgview=new ArrayList();
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@10.100.1.30:1521:kurnia","kurniadev","system");
			PreparedStatement ps=con.prepareStatement("select num_id,vch_img_name from mad_tb_img");

			ResultSet rst=ps.executeQuery();
			byte[] imagedata=null;
			String imgdata=null;
			while(rst.next())
			{
			java.sql.Blob imgblob=rst.getBlob("vch_img_name");
				imagedata=imgblob.getBytes(1,(int)imgblob.length());
				imgview.add(imagedata);
			}
			
			System.out.println("image name:"+imgview);
		
			session.setAttribute("imgViewList", imgview);
			
			
			}
			
		
		
		
		catch (Exception e) {
			System.out.println("View Image: "+e);
			
		}
		
		
			
	return mapping.findForward("viewImage");
	}


}
