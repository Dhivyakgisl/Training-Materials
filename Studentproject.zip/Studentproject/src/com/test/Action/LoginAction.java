package com.test.Action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.test.bean.LoginBean;
import com.test.dao.StudentDaoImpl;

public class LoginAction extends Action{
	
	public ActionForward execute(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response)
	{
		StudentDaoImpl std=new StudentDaoImpl();
		
	
		String uname=request.getParameter("uname");
		String pwd=request.getParameter("pwd");
		String module=request.getParameter("mod");
		
		
/*ActionMessages errors=new ActionMessages();
errors.add("uname",new ActionMessage("uname is invalid"));
request.setAttribute(Globals.ERROR_KEY,errors);*/
		
	
LoginBean loginBean=(LoginBean)form;

	if((std.checkdata(uname, pwd, module)) && (loginBean.getMod().equalsIgnoreCase("Student")))
	{
		
		return mapping.findForward("student");
	}
	else if((std.checkdata(uname, pwd, module)) && (loginBean.getMod().equalsIgnoreCase("Staff")))

	{
		return mapping.findForward("staff");
	}
	else if((std.checkdata(uname, pwd, module)) && (loginBean.getMod().equalsIgnoreCase("Admin")))
	{
		return mapping.findForward("admin");
	}
	else
	{
		return mapping.findForward("success");	
	}
	
	
	
	
	}
	


}
