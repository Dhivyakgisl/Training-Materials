package com.test.Action;

import java.util.ArrayList;






import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.test.bean.RegisterBean;
import com.test.dao.StudentDaoImpl;





public class RegisterAction  extends DispatchAction{
	
@Override
	public ActionForward execute(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response)
	{
		RegisterBean registerBean=(RegisterBean)form;
		StudentDaoImpl studentDaoImpl=new StudentDaoImpl();
		
		
		
		ArrayList slist=new ArrayList();
		ArrayList dlist=new ArrayList();
		ArrayList ylist=new ArrayList();
		
		slist=(ArrayList)studentDaoImpl.getstate();
		dlist=(ArrayList)studentDaoImpl.getdepartment();
		ylist=(ArrayList)studentDaoImpl.getyear();
		

		request.setAttribute("stateList", slist);
		request.setAttribute("deptlist", dlist);
		request.setAttribute("yearlist", ylist);
		
		studentDaoImpl.savedata(form,request);
		studentDaoImpl.viewdata(form, request);
		request.getSession().setAttribute("result", "Record Saved Successfully...");
		
			return mapping.findForward("register_result");	
		}

		
	
}
