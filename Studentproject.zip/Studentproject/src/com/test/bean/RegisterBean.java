package com.test.bean;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;
import org.apache.struts.upload.FormFile;

public class RegisterBean extends ActionForm {

	private int sid;
	private int hndeditInd;
	public int getHndeditInd() {
		return hndeditInd;
	}
	public void setHndeditInd(int hndeditInd) {
		this.hndeditInd = hndeditInd;
	}
	private String sname;
	private String check;
	public String getCheck() {
		return check;
	}
	public void setCheck(String check) {
		this.check = check;
	}
	private String dob;
	private String gender;
	private String state;
	private String city;
	private String department;
	private String year;
	private String language[];
	private String langs;
	private String psword;
	private String con_psword;
	private String email;
	private Long mobileno;
	private String select;
	private int stateid;
	private String stateName;

	private FormFile file;

	public FormFile getFile() {
		return file;
	}

	public void setFile(FormFile file) {
		this.file = file;
	}
	private int cityid;
	private String cityName;
	
	private int deptid;
	private String deptname;
	
	private int yrid;
	private String yrname;
	
	public String getLangs() {
		return langs;
	}
	public void setLangs(String langs) {
		this.langs = langs;
	}
	public int getYrid() {
		return yrid;
	}
	public void setYrid(int yrid) {
		this.yrid = yrid;
	}
	public String getYrname() {
		return yrname;
	}
	public void setYrname(String yrname) {
		this.yrname = yrname;
	}
	public int getDeptid() {
		return deptid;
	}
	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}
	public String getDeptname() {
		return deptname;
	}
	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	public int getCityid() {
		return cityid;
	}
	public void setCityid(int cityid) {
		this.cityid = cityid;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	ArrayList astate=new ArrayList();
	ArrayList acity=new ArrayList();
	ArrayList adepartment=new ArrayList();
	ArrayList ayear=new ArrayList();
	
	
	ArrayList stateList=new ArrayList();
	ArrayList cityList=new ArrayList();
	
	
	public ArrayList getCityList() {
		return cityList;
	}
	public void setCityList(ArrayList cityList) {
		this.cityList = cityList;
	}
	ArrayList list=new ArrayList();
	
	public ArrayList getList() {
		return list;
	}
	public void setList(ArrayList list) {
		this.list = list;
	}
	public ArrayList getStateList() {
		return stateList;
	}
	public void setStateList(ArrayList stateList) {
		this.stateList = stateList;
	}
	public int getSid() {
		return sid;
	}
	
	public String[] getLanguage() {
		return language;
	}
	public void setLanguage(String[] language) {
		this.language = language;
	}

	
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	
	
	public String getPsword() {
		return psword;
	}
	public void setPsword(String psword) {
		this.psword = psword;
	}
	public String getCon_psword() {
		return con_psword;
	}
	public void setCon_psword(String con_psword) {
		this.con_psword = con_psword;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getMobileno() {
		return mobileno;
	}
	public void setMobileno(Long mobileno) {
		
		this.mobileno = mobileno;
	}
	
	
	public int getStateid() {
		return stateid;
	}
	public void setStateid(int stateid) {
		this.stateid = stateid;
	}
	
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public ArrayList getAstate() {
		
		ArrayList alist=new ArrayList();
		alist.add("Andhra Pradesh");
		alist.add("Arunachal Pradesh");
		alist.add("Assam");
		alist.add("Bihar");
		alist.add("Chhattisgarh");
		alist.add("Goa");
		alist.add("Gujarat");
		alist.add("Haryana");
		alist.add("Himachal Pradesh");
		alist.add("Jammu and Kashmir");
		alist.add("Karnataka");
		alist.add("Kerala");
		alist.add("Punjab");
		alist.add("Rajasthan");
		alist.add("Tamil Nadu");
		alist.add("Uttar Pradesh");
		alist.add("West Bengal");
		return alist;
	}
	public void setAstate(ArrayList astate) {
		this.astate = astate;
	}
	public ArrayList getAcity() {
		return acity;
	}
	public void setAcity(ArrayList acity) {
		this.acity = acity;
	}
	public ArrayList getAdepartment() {
		return adepartment;
	}
	public void setAdepartment(ArrayList adepartment) {
		this.adepartment = adepartment;
	}
	public ArrayList getAyear() {
		return ayear;
	}
	public void setAyear(ArrayList ayear) {
		this.ayear = ayear;
	}
	
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	
	public String getSelect() {
		return select;
	}
	public void setSelect(String select) {
		this.select = select;
	}
	
	
	
	
}
