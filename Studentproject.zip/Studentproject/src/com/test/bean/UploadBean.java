package com.test.bean;

import org.apache.struts.action.ActionForm;
import org.apache.struts.upload.FormFile;
import org.apache.struts2.components.Param;
import org.apache.taglibs.standard.tag.common.core.ParamParent;

public class UploadBean extends ActionForm {
	
	private FormFile file;
	private int imgid;

	private String img;
	
	protected String paramProperty=null;
	
	
	
	public String getParamproperty() {
		return paramProperty;
	}

	public void setParamproperty(String paramproperty) {
		this.paramProperty = paramproperty;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public int getImgid() {
		return imgid;
	}

	public void setImgid(int imgid) {
		this.imgid = imgid;
	}

	public FormFile getFile() {
		return file;
	}

	public void setFile(FormFile file) {
		this.file = file;
	}
	
	

}
