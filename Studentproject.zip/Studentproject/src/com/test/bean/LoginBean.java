package com.test.bean;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

public class LoginBean extends ActionForm{
	
	private String uname;
	private String pwd;
	private String mod;
public String getMod() {
		return mod;
	}
	public void setMod(String mod) {
		this.mod = mod;
	}

	ArrayList module=new ArrayList();

public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getPwd() {
	return pwd;
}
public void setPwd(String pwd) {
	this.pwd = pwd;
}
public ArrayList getModule() {
	ArrayList list=new ArrayList();
	list.add("Student");
	list.add("Staff");
	list.add("Admin");
	return list;
}
public void setModule(ArrayList module) {
	this.module = module;
}


	
	
}
