package com.test.dao;

import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.annotation.WebServlet;
import java.util.Collection;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;

import com.test.Action.RegisterAction;
import com.test.bean.RegisterBean;

public interface StudentDao {

	public boolean checkdata(String uname,String pwd,String module);
	
	
	
	public Collection getdepartment();
	public Collection getyear();
	
	public void savedata(ActionForm form,HttpServletRequest response);
	
	public void viewdata(ActionForm form,HttpServletRequest request);
	
	public void deldata(HttpServletRequest request);
	
	public void checkoperation(int s);
	
	void editdata(HttpServletRequest request,HttpServletResponse response) throws IOException;
	
	void statechange(HttpServletRequest request);

	public Collection getstate();
	
	public void exportExcel();
	
	public void exportPdf();
	
	public void exportXml();
	
	

	
	
	
}
