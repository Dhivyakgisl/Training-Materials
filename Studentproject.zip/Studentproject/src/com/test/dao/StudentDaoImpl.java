package com.test.dao;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import oracle.jdbc.driver.OracleTypes;

import org.apache.poi.hssf.record.formula.functions.Replace;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.struts.action.ActionForm;

import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.test.bean.RegisterBean;



public class StudentDaoImpl extends HttpServlet implements StudentDao {
	@Override
	public boolean checkdata(String uname, String pwd, String module) {
		try
		{
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		Connection  con = DriverManager.getConnection("jdbc:oracle:thin:@10.100.1.30:1521:kurnia","kurniadev","system");

		PreparedStatement ps=con.prepareStatement("select * from mad_tb_student_project where vch_uname='"+uname+"' and vch_pwd='"+pwd+"' and vch_module='"+module+"'");
		
		
		ResultSet rst=ps.executeQuery();
		if(rst.next())
		{
			uname=rst.getString("vch_uname");
			pwd=rst.getString("vch_pwd");
			module=rst.getString("vch_module");
			System.out.println(uname);
			System.out.println(pwd);
			System.out.println(module);
			return true;
		}
		con.close();
		
		}catch(Exception e)
		{
			System.out.println("Error Check uname,pwd,"+e);
		}

		return false;
	}

	
	
		

	@Override
	public Collection getdepartment() {
		ArrayList deptlist=new ArrayList();
		try{ 
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@10.100.1.30:1521:kurnia","kurniadev","system");    
			Statement stmt=con.createStatement();  
		ResultSet rst=stmt.executeQuery("select * from MAD_TB_STUDENT_DEPT");
		while(rst.next())
		{
			RegisterBean registerBean=new RegisterBean();
			registerBean.setDeptid(rst.getInt("NUM_DEPT_ID"));
			registerBean.setDeptname(rst.getString("VCH_DEPT_NAME"));
			
			deptlist.add(registerBean);
	
		}
			
			
			}catch(Exception e){ System.out.println("Department"+e);}
		
		return deptlist;
	}

	@Override
	public Collection getyear() {
		ArrayList yearlist=new ArrayList();
		try{ 
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@10.100.1.30:1521:kurnia","kurniadev","system");    
			Statement stmt=con.createStatement();  
			Statement stm=con.createStatement();  
			ResultSet rst=stm.executeQuery("select * from MAD_TB_STUDENT_YEAR");
			while(rst.next())
				
			{
				RegisterBean registerBean=new RegisterBean();
				registerBean.setYrid(rst.getInt("NUM_YID"));
				registerBean.setYrname(rst.getString("YNAME"));
				
				yearlist.add(registerBean);
					}
								
				}catch(Exception e){ System.out.println("year"+e);}
			
			return yearlist;
		}
	

	@Override
	public void savedata(ActionForm form,HttpServletRequest request) {
		
		RegisterBean registerBean=(RegisterBean)form;
		
		try{ 
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@10.100.1.30:1521:kurnia","kurniadev","system"); 
			String insertstoreproc="{call  mad_pr_student_register(?,?,?,?,?,?,?,?,?,?,?,?,?)}";		
			CallableStatement callableStatement=con.prepareCall(insertstoreproc);
			callableStatement.setInt(1, registerBean.getSid());
			callableStatement.setString(2,registerBean.getSname());
			callableStatement.setString(3,registerBean.getDob());
			callableStatement.setString(4,registerBean.getGender());
			callableStatement.setString(5,registerBean.getState());
			callableStatement.setString(6,registerBean.getCity());
			callableStatement.setString(7,registerBean.getDepartment());
			callableStatement.setString(8,registerBean.getYear());
			callableStatement.setString(9,Arrays.toString(registerBean.getLanguage()));
			callableStatement.setString(10,registerBean.getPsword());
		    callableStatement.setString(11,registerBean.getCon_psword());
			callableStatement.setString(12,registerBean.getEmail());
			callableStatement.setLong(13,registerBean.getMobileno());
			 callableStatement.executeUpdate();
			request.setAttribute("s","inserted successfylly");
			}catch(Exception e){ 
				request.setAttribute("st","invalid inserted");
				System.out.println("insert data"+e);
				}
		
		
	}

	@Override
	public void viewdata(ActionForm form, HttpServletRequest request) {
		
		ArrayList<RegisterBean> list=new ArrayList<RegisterBean>();
		
		HttpSession session=request.getSession(true);
	
		try{ 
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			Connection con=DriverManager.getConnection( "jdbc:oracle:thin:@10.100.1.30:1521:kurnia","kurniadev","system");
			
			String viewdata="{call mad_pr_student_view_data(?)}";
			
			CallableStatement callableStatement=con.prepareCall(viewdata);
			callableStatement.registerOutParameter(1,OracleTypes.CURSOR);
		ResultSet rst=callableStatement.executeQuery();
			rst=(ResultSet)callableStatement.getObject(1);
			RegisterBean registerBean2=(RegisterBean)form;
		while(rst.next())
			{
			      RegisterBean registerBean=new RegisterBean();
				                      
			      String s=rst.getString("VCH_LANGUAGE");
			String firstval=s.replace("[","");
			String lastval=firstval.replace("]", "");
			
			      System.out.println("madhu language known:"+lastval);
				registerBean.setSid(rst.getInt("NUM_SID"));
				registerBean.setSname(rst.getString("VCH_SNAME"));         
				registerBean.setDob(rst.getString("DT_DOB"));
				registerBean.setGender(rst.getString("VCH_GENDER"));
				registerBean.setState(rst.getString("VCH_STATE"));
				registerBean.setCity(rst.getString("VCH_CITY"));
				registerBean.setDepartment(rst.getString("VCH_DEPARTMENT"));
				registerBean.setYear(rst.getString("VCH_YEAR"));
				registerBean.setLangs(lastval);
				registerBean.setPsword(rst.getString("VCH_PSWORD"));
				registerBean.setCon_psword(rst.getString("VCH_CON_PSWORD"));
				registerBean.setEmail(rst.getString("VCH_EMAIL"));
				registerBean.setMobileno(rst.getLong("NUM_MOBILENO"));
				
				list.add(registerBean);
				
			}
			
			registerBean2.setList(list);
			
			session.setAttribute("list", list);
			con.close();
		}
		catch(Exception e)
		{
			System.out.println("view"+e);
		}
	}

	@Override
	public void deldata(HttpServletRequest request) {
String del=request.getParameter("deleteval");

System.out.println("Delete value is:"+del);
try{ 
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@10.100.1.30:1521:kurnia","kurniadev","system");    
			Statement stmt=con.createStatement();  
			stmt.executeQuery("delete from mad_tb_register where num_sid='"+del+"'");  
			request.setAttribute("delete","Record Deleted Successfully");
			}catch(Exception e){ System.out.println(e);}
	}

	@Override
	public void checkoperation(int s) {
		 int st;

		try{ 
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@10.100.1.30:1521:kurnia","kurniadev","system");    
			Statement stmt=con.createStatement();  
			/*stmt.executeQuery("select num_id from mad_tb_register where num_sid='"+st+"'");*/  
			}catch(Exception e){ System.out.println("Delete dat:"+e);}
	}

	@Override
	public void editdata(HttpServletRequest request,HttpServletResponse response) throws IOException {
	}

	@Override
	public Collection getstate() {
		
		ArrayList slist=new ArrayList();
		
		try{ 
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@10.100.1.30:1521:kurnia","kurniadev","system");    
			Statement stmt=con.createStatement();  
			ResultSet  rst=stmt.executeQuery("select * from mad_tb_student_state_all order by num_state_id asc");
			while(rst.next())
			{
				RegisterBean registerBean=new RegisterBean();
				registerBean.setStateid(rst.getInt("num_state_id"));
				registerBean.setStateName(rst.getString("VCH_STATE_name"));
				slist.add(registerBean);
			}
			}catch(Exception e){ System.out.println("Get State:"+e);}
	
		return slist;
	}

	
		
	public ArrayList getCityList(int stateid)
	{
		ArrayList cityList=new ArrayList();
		try{ 
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@10.100.1.30:1521:kurnia","kurniadev","system");    
			Statement stmt=con.createStatement();  
			ResultSet  rst=stmt.executeQuery("select * from mad_tb_student_city where num_state_id='"+stateid+"'");
			while(rst.next())
			{
				RegisterBean registerBean=new RegisterBean();
				registerBean.setCityid(rst.getInt("num_city_id"));
				registerBean.setCityName(rst.getString("vch_city_name"));
				cityList.add(registerBean);
			}
			}catch(Exception e){ System.out.println("city"+e);}
	return cityList;
		
	}
	
	

	@Override
	public void statechange(HttpServletRequest request) {
		
		

		String country=request.getParameter("stateval");

        System.out.println("state madhu name is:"+ country);
		
	}

	@Override
	public void exportExcel() {
		try{
			String filename="C:/Users/mohamedah/Desktop/StudentXl.xls" ;
			HSSFWorkbook hwb=new HSSFWorkbook();
			HSSFSheet sheet =  hwb.createSheet("new sheet");
			HSSFRow rowhead=   sheet.createRow((short)0);
			rowhead.createCell((short) 0).setCellValue("StudentId");
			rowhead.createCell((short) 1).setCellValue("StudentName");
			rowhead.createCell((short) 2).setCellValue("Date of Birth");
			rowhead.createCell((short) 3).setCellValue("Gender");
			rowhead.createCell((short) 4).setCellValue("State");
			rowhead.createCell((short) 5).setCellValue("city");
            rowhead.createCell((short) 6).setCellValue("Department");
            rowhead.createCell((short) 7).setCellValue("year");
            rowhead.createCell((short) 8).setCellValue("language");
			rowhead.createCell((short) 9).setCellValue("password");
			rowhead.createCell((short) 10).setCellValue("confirm_password");
			rowhead.createCell((short) 11).setCellValue("EmailId");
			rowhead.createCell((short) 12).setCellValue("Mobile");
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.100.1.30:1521:kurnia","kurniadev","system");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from mad_tb_register");
			int i=1;
			while(rs.next()){
			HSSFRow row=   sheet.createRow((short)i);
			row.createCell((short) 0).setCellValue(rs.getString("NUM_SID"));
			row.createCell((short) 1).setCellValue(rs.getString("VCH_SNAME"));
			row.createCell((short) 2).setCellValue(rs.getString("DT_DOB"));
			row.createCell((short) 3).setCellValue(rs.getString("VCH_GENDER"));
			row.createCell((short) 4).setCellValue(rs.getString("VCH_STATE"));
			row.createCell((short) 5).setCellValue(rs.getString("VCH_CITY"));
			row.createCell((short) 6).setCellValue(rs.getString("VCH_DEPARTMENT"));
			row.createCell((short) 7).setCellValue(rs.getString("VCH_YEAR"));
			row.createCell((short) 8).setCellValue(rs.getString("VCH_LANGUAGE"));
			row.createCell((short) 9).setCellValue(rs.getString("VCH_PSWORD"));
			row.createCell((short) 10).setCellValue(rs.getString("VCH_CON_PSWORD"));
			row.createCell((short) 11).setCellValue(rs.getString("VCH_EMAIL"));
			row.createCell((short) 12).setCellValue(rs.getString("NUM_MOBILENO"));

			i++;
			}
			FileOutputStream fileOut =  new FileOutputStream(filename);
			hwb.write(fileOut);
			fileOut.close();
			System.out.println("Your excel file has been generated!");

			} catch ( Exception ex ) {
			    System.out.println("Excel Export : "+ex);

			}	
		
	}
	@Override
	public void exportPdf() {
		
		try {
			OutputStream file = new FileOutputStream(new File("C:/Users/mohamedah/Desktop/StudentPdf.pdf"));

			Document document = new Document();
			PdfWriter.getInstance(document, file);
            PdfPTable table=new PdfPTable(13);
			document.open();
			table.addCell("StudentId");
			table.addCell("StudentName");
			table.addCell("Date of Birth");
			table.addCell("Gender");
			table.addCell("State");
			table.addCell("City");
			table.addCell("Department");
			table.addCell("Year");
			table.addCell("Language");
			table.addCell("password");
			table.addCell("confirm password");
			table.addCell("Email ID");
			table.addCell("Mobile");
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jbdc:oracle:thin:@10.100.1.30:1521:KURNIA", "kurniadev", "system");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("Select * from mad_tb_register");
			while(rs.next())
			{
			table.addCell(rs.getString("NUM_SID"));
			table.addCell(rs.getString("VCH_SNAME"));
			table.addCell(rs.getString("DT_DOB"));
			table.addCell(rs.getString("VCH_GENDER"));
			table.addCell(rs.getString("VCH_STATE"));
			table.addCell(rs.getString("VCH_CITY"));
			table.addCell(rs.getString("VCH_DEPARTMENT"));
			table.addCell(rs.getString("VCH_YEAR"));
			table.addCell(rs.getString("VCH_LANGUAGE"));
			table.addCell(rs.getString("VCH_PSWORD"));
			table.addCell(rs.getString("VCH_CON_PSWORD"));
			table.addCell(rs.getString("VCH_EMAIL"));
			table.addCell(rs.getString("NUM_MOBILENO"));
			}
			document.add(table);
			document.close();
			file.close();
			
		} catch (Exception e) {
  System.out.println("Pdf Error :"+e);
	
		}
	
		
		
	}

	@Override
	public void exportXml() {
		try {
	           Class.forName("oracle.jdbc.driver.OracleDriver");
	         Connection  con = DriverManager.getConnection("jdbc:oracle:thin:@10.100.1.30/KURNIA","kurniadev","system");
	           PreparedStatement st = con.prepareStatement("select * from mad_tb_register");
	          ResultSet rs = st.executeQuery();
	           ResultSetMetaData rsmd = rs.getMetaData();
	           int colCount = rsmd.getColumnCount();
	           StringBuilder b = new StringBuilder("<table>\n");
	           int num = 1;
	           while (rs.next()) {
	               b.append("<row>");
	               b.append("<num>").append(num++).append("</num>");
	               for (int i = 1; i <= colCount; i++) {
	                   String columnName = rsmd.getColumnName(i);
	                   b.append('<').append(columnName).append('>');
	                   b.append(rs.getObject(i));
	                   b.append("</").append(columnName).append('>');
	               }
	               b.append("</row>\n");
	           }
	           b.append("</table>");
	        
//			 System.out.println(b.toString());
			 String data=b.toString();
	        File file=new File("C:/Users/mohamedah/Desktop/StudentXml.xml");
	        FileWriter fw=new FileWriter(file.getAbsoluteFile());
	        BufferedWriter bw=new BufferedWriter(fw);
	        bw.write(data);
	        bw.close();
	         System.out.println("Xml file Generated SuccessFully");
	       } catch (Exception e) {
	           System.out.println("Xml Error :"+e);
	         
	       }
		
		
		
	}
	
		
	
	


}
